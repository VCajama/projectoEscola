

<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">

            <div class="row-one">
                <div class="col-md-4 widget">
                    <div class="stats-left ">
                        <h4>Alunos</h4>
                        <h5>Inscritos</h5>
                    </div>
                    <div class="stats-right">
                        <label> 
                            <?php foreach ($alunos->result() as $row) { ?>   
                                <?php echo $row->cont; ?>
                            <?php } ?>
                        </label>
                    </div>
                    <div class="clearfix"> </div>	
                </div>
                <div class="col-md-4 widget states-mdl">
                    <div class="stats-left">     
                        <h4>Professores</h4>
                        <h5>Inscritos</h5>

                    </div>
                    <div class="stats-right">
                        <label> 
                            <?php foreach ($professores->result() as $row) { ?>   

                                <?php echo $row->cont; ?>

                            <?php } ?>
                        </label>
                    </div>
                    <div class="clearfix"> </div>	
                </div>
                <div class="col-md-4 widget states-last">
                    <div class="stats-left">
                        <h4>Turmas</h4>
                        <h5>Criadas</h5>

                    </div>
                    <div class="stats-right">
                        <label> 
                            <?php foreach ($turmas->result() as $row) { ?>   

                                <?php echo $row->cont; ?>

                            <?php } ?>
                        </label>
                    </div>
                    <div class="clearfix"> </div>	
                </div>
                <div class="clearfix"> </div>


            </div>

            <div class="row">

                <div class="row">
                    <div class="col-md-4 stats-info widget">
                        <div class="stats-title">
                            <h4 class="title">TURMAS</h4>
                        </div>
                        <div class="stats-body">
                            <ul class="list-unstyled">
                                <?php foreach ($alunoTurma->result() as $row) { ?>   
                                    <li><?php echo $row->turma; ?> <span class="pull-right"><?php echo $row->qtdAluno; ?></span>  
                                        <div class="progress progress-striped active progress-right">
                                            <div class="bar green" style="width:<?php echo $row->qtdAluno; ?>;"></div> 
                                        </div>
                                    </li>


                                <?php } ?>


                            </ul>
                        </div>
                    </div>
                    <div class="col-md-8 stats-info stats-last widget-shadow">
                        <table class="table stats-table ">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>TURMAS</th>
                                    <th>PREÇÁRIO</th>
                                    <th>NÚMERO DE TURMAS</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $cout = 1; ?>
                                <?php foreach ($getCurso->result() as $row) { ?> 
                                    <tr>

                                        <th scope="row"><?php echo $cout++; ?></th>
                                        <td> <?php echo $row->turma; ?></td>
                                        <td> <?php echo $row->valor . ' R$'; ?> 
                                        <td> <?php echo $row->qtdTurma; ?>

                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="clearfix"> </div>
                </div>
               
                <div class="clearfix"> </div>
            </div>
            
            <div class = "clearfix"> </div>
        </div>

        <div class = "clearfix"> </div>
    </div>
</div>
</div>
</div>
</div>
