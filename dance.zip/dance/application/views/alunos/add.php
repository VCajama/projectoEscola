<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">
            <!-- <h3 class="title1">Gerir Alunos</h3> -->
            <div class="container">
                <div class="row center">
                    <div class="col-md-7">
                        <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                           
                            <div class="form-title">

                                <h4>Cadastrar Aluno </h4>

                            </div>
                            <div class="form-body">
                                <form method="POST" name="form_add"> 

                                    <div class="form-group"> 
                                        <label>Nome</label> 
                                        <input type="text" class="form-control" name="nome" placeholder="Nome do aluno" value="<?php echo set_value('nome'); ?>"> 
                                        <?php echo form_error('nome', '<span class="help-block">', '</span>'); ?>
                                    </div>  
                                    <div class="form-group"> 
                                        <label>Endereço</label> 
                                        <input type="text" class="form-control" name="endereco" placeholder="Endereco do aluno" value="<?php echo set_value('endereco'); ?>"> 
                                        <?php echo form_error('endereco', '<span class="help-block">', '</span>'); ?>
                                    </div> 
                                    <div class="form-group"> 
                                        <label>Telefone</label> 
                                        <input type="text" class="form-control" name="telefone" placeholder="telefone do aluno" value="<?php echo set_value('telefone'); ?>"> 
                                        <?php echo form_error('telefone', '<span class="help-block">', '</span>'); ?>
                                    </div>
                                    <div class="form-group"> 
                                        <label>Telefone alternativo</label> 
                                        <input type="text" class="form-control" name="telefoneAlternativo" placeholder="Telefone alternativo do aluno" value="<?php echo set_value('telefoneAlternativo'); ?>"> 
                                        <?php echo form_error('telefoneAlternativo', '<span class="help-block">', '</span>'); ?>
                                    </div>
                                    <div class="form-group data-custon-pick"> 
                                        <label>Data de nascimento</label> 
                                        <input type="text" class="form-control" name="dataNascimento" placeholder="Data de nascimento do aluno" value="<?php echo set_value('dataNascimento'); ?>"> 
                                        <?php echo form_error('dataNascimento', '<span class="help-block">', '</span>'); ?>
                                    </div>
                                  

                                        <div class="form-group"> 
                                            <label  class="control-label">Género</label>
                                            <select name="sexo"  class="form-control1">
                                                <option value="Masculino">Masculino</option>
                                                <option value="Feminino" >Feminino</option>
                                            </select>
                                        </div> 
                                        <div class="form-group"> 
                                            <label  class="control-label">Aluno activo</label>
                                            <select name="aluno_activo"  class="form-control1">
                                                <option value="0" >Não</option>
                                                <option value="1" >Sim</option>
                                            </select>
                                        </div>

                                        <button type="submit" class="btn btn-default">Salvar</button>
                                </form>
                            </div>
                        </div>
                    </div>   
                </div>

            </div>
        </div>
    </div>
</div>
