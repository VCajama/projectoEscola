<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">
            <!-- <h3 class="title1">Gerir Alunos</h3> -->
            <div class="container">
                <div class="row center">
                    <div class="col-md-7">
                        <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                            <div class="form-title">

                                <h4>Pagar Mensalidade </h4>

                            </div>
                            <div class="form-body">
                                <form method="POST" name="form_addMensalidade"> 

                                    <div class="form-group"> 
                                        <label>Nome</label> 
                                        <input type="hidden"   class="form-control" name="nome" placeholder="Nome do aluno" value="<?php echo $alunos->nome; ?>"> 
                                        <input disabled="" id="disabledinput"  class="form-control" name="" placeholder="Nome do aluno" value="<?php echo $alunos->nome; ?>"> 

                                        <?php echo form_error('nome', '<span class="help-block">', '</span>'); ?>
                                    </div>  
                                    <div class="form-group"> 
                                        <label>Valor a pagar</label> 
                                        <input type="hidden"  class="form-control" name="valorPropina" placeholder="valor da propina" value="<?php echo $alunos->valorPropina; ?>"> 
                                        <input disabled="" id="disabledinput"  class="form-control" name="" placeholder="Nome do aluno" value="<?php echo $alunos->valorPropina; ?>"> 
                                        <?php echo form_error('valorPropina', '<span class="help-block">', '</span>'); ?>
                                    </div> 
                                    <div class="form-group"> 
                                        <input  type="hidden" class="form-control" name="codAluno" placeholder="" value="<?php echo $alunos->codAluno; ?>"> 

                                    </div> 

                                    <div class="form-group"> 
                                        <input type="hidden" class="form-control" name="estado" placeholder="" value="<?php echo 'PAGO'; ?>"> 
                                    </div>  
                                    <div class="form-group"> 
                                        <input type="hidden" class="form-control" name="totalPagamento" placeholder="" value="<?php echo $alunos->totalPagamento + 1; ?>"> 
                                    </div> 

                                    <div class="form-group"> 
                                        <label  class="control-label">Mês</label>
                                        <select name="mes"  class="form-control1">
                                            <?php
                                            foreach ($meses as $mes) {
                                                if ($alunos->totalPagamento <> $mes->codMes) {
                                                    if ($alunos->totalPagamento < $mes->codMes) {
                                                        ?>                         
                                                        <option value="<?php echo $mes->nome; ?>">
                                                            <?php
                                                            echo $mes->nome;
                                                            break;
                                                        }
                                                    }
                                                    ?>
                                                </option>
<?php } ?>
                                        </select>
                                    </div> 

                                    <button type="submit" class="btn btn-default">Salvar</button>
                                </form>
                            </div>
                        </div>
                    </div>   
                </div>

            </div>
        </div>
    </div>
</div>
