f<div class="main-content">

    <?php $this->load->view('layout/sidebar') ?>

    <?php $this->load->view('layout/navbar') ?>

    <div id="page-wrapper">
        <div class="main-page">
       
            <div class="container">
                <div class="row center">
                    <div class="col-md-7">
                        <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                            <p><strong>&nbsp;&nbsp;Última actualização: &nbsp;&nbsp;</strong><?php echo formata_data_banco_sem_hora($cursos->dataAlteracao); ?> </p>
                            <div class="form-title">

                                <h4>Actualizar Curso </h4>

                            </div>
                            <div class="form-body">
                                <form method="POST" name="form_edit"> 

                                    <div class="form-group"> 
                                        <label>Nome</label> 
                                        <input type="text" class="form-control" name="nome" placeholder="Nome do curso" value="<?php echo $cursos->nome; ?>"> 
                                        <?php echo form_error('nome', '<span class="help-block">', '</span>'); ?>
                                    </div>  

                                    <div class="form-group"> 
                                        <label  class="control-label">Curso activo</label>
                                        <select name="curso_activo"  class="form-control1">
                                            <option value="0" <?php echo ($cursos->curso_activo == '0') ? 'selected' : '' ?>>Não</option>
                                            <option value="1" <?php echo ($cursos->curso_activo == '1') ? 'selected' : '' ?>>Sim</option>
                                        </select>
                                    </div>

                                    <button type="submit" class="btn btn-default">Salvar</button>
                                </form>
                            </div>
                        </div>
                    </div>   
                </div>

            </div>
        </div>
    </div>
</div>
