<div class=" sidebar" role="navigation">
    <div class="navbar-collapse">
        <nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
            <ul class="nav" id="side-menu">
                <li>
                    <a href="<?php echo base_url('home/'); ?>"><i class="fa fa-home nav_icon"></i>Início</a>
                </li>

                <li>
                    <a href="<?php echo base_url('professores/'); ?>"><i class="fa fa-home nav_icon"></i>Professores</a>
                </li>
                <li>
                    <a href="<?php echo base_url('alunos/'); ?>"><i class="fa fa-home nav_icon"></i>Alunos</a>
                </li>
                <?php if($this->ion_auth->is_admin()): ?>
              
                    <li>
                        <a href="<?php echo base_url('usuarios/'); ?>"><i class="fa fa-home nav_icon"></i>Usuários</a>
                    </li>
                    
                    <li>
                        <a href="#"><i class="fa fa-cogs nav_icon"></i>Configurações  <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li>
                                <a href="<?php echo base_url('turmas/'); ?>">Turmas</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('cursos/'); ?>">Cursos</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('especialidades/'); ?>">Especialidades</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url('mensalidades/'); ?>">Mensalidades</a>
                            </li>
                        </ul>
                        <!-- /nav-second-level -->
                    </li>
                      <li>
                        <a href="#"><i class="fa fa-cogs nav_icon"></i>Relatórios <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li>
                                <a href="<?php echo base_url(''); ?>">Alunos</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url(''); ?>">Professores</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url(''); ?>">Turmas</a>
                            </li>
                            <li>
                                <a href="<?php echo base_url(''); ?>">Mensalidades</a>
                            </li>
                        </ul>
                        <!-- /nav-second-level -->
                    </li>
               <?php endif;?>
                <li>
                    <a href="#"><i class="fa fa-home nav_icon"></i>Sair</a>
                </li>

            </ul>
            <div class="clearfix"> </div>
            <!-- //sidebar-collapse -->
        </nav>
    </div>
</div>