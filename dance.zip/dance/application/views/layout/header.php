<!DOCTYPE HTML>
<html>
<head>
<title>Novus Admin Panel an Admin Panel Category Flat Bootstrap Responsive Website Template | Blank Page :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Novus Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="<?php echo base_url('public/css/bootstrap.css')?>" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="<?php echo base_url('public/css/style.css')?>" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="<?php echo base_url('public/css/font-awesome.css')?>" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
 <script src="<?php echo base_url('public/js/jquery-1.11.1.min.js')?>"></script>
 <script src="<?php echo base_url('public/js/modernizr.custom.js')?>"></script>
 <script type="text/javascript" src="http://services.iperfect.net/js/IP_generalLib.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="<?php echo base_url('public/css/animate.css')?>" rel="stylesheet" type="text/css" media="all">
<script src="<?php echo base_url('public/js/wow.min.js')?>"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="<?php echo base_url('public/js/metisMenu.min.js')?>"></script>
<script src="<?php echo base_url('public/js/custom.js')?>"></script>
<link href="<?php echo base_url('public/css/custom.css')?>" rel="stylesheet">
<!--//Metis Menu -->
</head> 
<body class="cbp-spmenu-push">
