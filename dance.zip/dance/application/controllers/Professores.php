<?php

defined('BASEPATH') OR exit('Acção não permitida');

class Professores extends CI_Controller {

    public function __construct() {
        parent::__construct();
         if(!$this->ion_auth->logged_in()){
            redirect('login');
        }
    }

    public function index() {

        $data = array(
            'titulo' => 'Listar professores',
            'professores' => $this->core_model->get_all('professor'),
        );
        $this->load->view('layout/header', $data);
        $this->load->view('professores/index');
        $this->load->view('layout/footer');
    }

    public function edit($professor_id = NULL) {
        //     !$professor_id ||!$this->ion_auth->user($professor_id)->row()
        if (!$professor_id || !$this->core_model->get_by_id('professor', array('codProfessor=' => $professor_id))) {
            $this->session->set_flashdata('error', 'Usuário não encontrado');
            exit('professores');
        } else {
            $this->form_validation->set_rules('nome', '', 'trim|required');
            $this->form_validation->set_rules('dataNascimento', '', 'required');
            $this->form_validation->set_rules('endereco', '', 'trim|required');
            $this->form_validation->set_rules('sexo', '', 'required');
            $this->form_validation->set_rules('telefone', '', 'required|min_length[13]|max_length[15]');
            $this->form_validation->set_rules('professor_activo', '', 'required');
            if ($this->form_validation->run()) {
                $data = elements(
                        array(
                    'nome',
                    'dataNascimento',
                    'endereco',
                    'sexo',
                    'telefone',
                    'professor_activo',
                        ), $this->input->post()
                );

                $this->core_model->update('professor', $data, array('codProfessor=' => $professor_id));

                redirect('professores');
            } else {
                $data = array(
                    'titulo' => 'Editar Professor',
                    'professores' => $this->core_model->get_by_id('professor', array('codProfessor=' => $professor_id)),
                );
                $this->load->view('layout/header', $data);
                $this->load->view('professores/edit');
                $this->load->view('layout/footer');
            }
        }
    }

    public function del($professor_id = NULL) {
        if (!$professor_id || !$this->core_model->get_by_id('professor', array('codProfessor=' => $professor_id))) {
            $this->session->set_flashdata('error', 'Professor não encontrado');
            redirect('professores');
        }
        if (!$this->core_model->delete('professor', array('codProfessor=' => $professor_id))) {
            $this->session->set_flashdata('sucess', 'Professor excluído com sucesso');
            redirect('professores');
        } else {
            $this->session->set_flashdata('sucess', 'Erro ao excluír o professor');
            redirect('professores');
        }
    }

    public function add() {
        $this->form_validation->set_rules('nome', '', 'trim|required');
        $this->form_validation->set_rules('dataNascimento', '', 'required');
        $this->form_validation->set_rules('endereco', '', 'trim|required');
        $this->form_validation->set_rules('sexo', '', 'required');
        $this->form_validation->set_rules('telefone', '', 'required|min_length[13]|max_length[15]');
        $this->form_validation->set_rules('professor_activo', '', 'required');


        if ($this->form_validation->run()) {
            $data = elements(
                    array(
                'nome',
                'dataNascimento',
                'endereco',
                'sexo',
                'telefone',
                'professor_activo',
                    ), $this->input->post()
            );

            $this->core_model->insert('professor', $data, $professor_id);
            redirect('professores');
        } else {

            $data = array(
                'titulo' => 'Cadastrar Professores',
            );


            $this->load->view('layout/header', $data);
            $this->load->view('professores/add');
            $this->load->view('layout/footer');
        }
    }

}
