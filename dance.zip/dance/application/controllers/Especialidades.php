<?php

defined('BASEPATH') OR exit('Acção não permitida');

class Especialidades extends CI_Controller {

    public function __construct() {
        parent::__construct();
         if(!$this->ion_auth->logged_in()){
            redirect('login');
        }
    }

    public function index() {

        $data = array(
            'titulo' => 'Listar especialidades',
            'especialidades' => $this->core_model->get_all('especialidade'),
        );
        $this->load->view('layout/header', $data);
        $this->load->view('especialidades/index');
        $this->load->view('layout/footer');
    }

    public function del($especialidade_id = NULL) {
        if (!$especialidade_id || !$this->core_model->get_by_id('especialidade', array('codEspecialidade=' => $especialidade_id))) {
            $this->session->set_flashdata('error', 'Especialidade não encontrado');
            redirect('especialidades');
        }
        if (!$this->core_model->delete('especialidade', array('codEspecialidade=' => $especialidade_id))) {
            $this->session->set_flashdata('sucess', 'Especialidade excluído com sucesso');
            redirect('especialidades');
        } else {
            $this->session->set_flashdata('sucess', 'Erro ao excluír o especialidade');
            redirect('especialidades');
        }
    }

    public function edit($especialidade_id = NULL) {

        if (!$especialidade_id || !$this->core_model->get_by_id('especialidade', array('codEspecialidade=' => $especialidade_id))) {
            $this->session->set_flashdata('error', 'Usuário não encontrado');
            exit('especialidades');
        } else {
            $this->form_validation->set_rules('nome', '', 'trim|required');
            $this->form_validation->set_rules('especialidade_activo', '', 'required');
            if ($this->form_validation->run()) {
                $data = elements(
                        array(
                    'nome',
                    'especialidade_activo',
                        ), $this->input->post()
                );

                $this->core_model->update('especialidade', $data, array('codEspecialidade=' => $especialidade_id));

                redirect('especialidades');
            } else {
                $data = array(
                    'titulo' => 'Editar especialidade',
                    'especialidades' => $this->core_model->get_by_id('especialidade', array('codEspecialidade=' => $especialidade_id)),
                );
                $this->load->view('layout/header', $data);
                $this->load->view('especialidades/edit');
                $this->load->view('layout/footer');
            }
        }
    }

     public function add() {
        $this->form_validation->set_rules('nome', '', 'trim|required|is_unique[especialidade.nome]');
        $this->form_validation->set_rules('especialidade_activo', '', 'required');
        if ($this->form_validation->run()) {
            $data = elements(
                    array(
                'nome',
                'especialidade_activo',
                    ), $this->input->post()
            );

            $this->core_model->insert('especialidade', $data, $especialidade_id);
            redirect('especialidades');
        } else {

            $data = array(
                'titulo' => 'Cadastrar especialidades',
            );


            $this->load->view('layout/header', $data);
            $this->load->view('especialidades/add');
            $this->load->view('layout/footer');
        }
    }
}
