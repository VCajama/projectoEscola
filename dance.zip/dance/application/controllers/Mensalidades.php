<?php

defined('BASEPATH') OR exit('Acção não permitida');

class Mensalidades extends CI_Controller {

    public function __construct() {
        parent::__construct();
         if(!$this->ion_auth->logged_in()){
            redirect('login');
        }
    }

    public function index() {

        $data = array(
            'titulo' => 'Listar mensalidades',
            'mensalidades' => $this->core_model->get_all('mensalidade'),
            'alunos' => $this->core_model->get_all('aluno'),
            'meses' => $this->core_model->get_all('mes'),
        );
        $this->load->view('layout/header', $data);
        $this->load->view('mensalidades/index');
        $this->load->view('layout/footer');
    }

    public function add() {

        $this->form_validation->set_rules('nome', '', 'trim|required');
        $this->form_validation->set_rules('endereco', '', 'trim|required');
        if ($this->form_validation->run()) {
            $data = elements(
                    array(
                'codAluno',
                'codMes',
                'valorPago',
                    ), $this->input->post()
            );

            $this->core_model->insert('mensalidade', $data, $mensalidade_id);
            redirect('mensalidades');
        } else {

            $data = array(
                'titulo' => 'Cadastrar Mensalidades',
            );


            $this->load->view('layout/header', $data);
            $this->load->view('mensalidades/add');
            $this->load->view('layout/footer');
        }
    }

}
