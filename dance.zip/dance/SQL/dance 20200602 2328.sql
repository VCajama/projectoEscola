-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.27


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema escola_bd
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ escola_bd;
USE escola_bd;

--
-- Table structure for table `escola_bd`.`aluno`
--

DROP TABLE IF EXISTS `aluno`;
CREATE TABLE `aluno` (
  `codAluno` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  `endereco` varchar(45) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `telefoneAlternativo` varchar(45) DEFAULT NULL,
  `dataNascimento` datetime DEFAULT NULL,
  `sexo` varchar(10) DEFAULT NULL,
  `aluno_activo` int(10) unsigned NOT NULL DEFAULT '0',
  `dataAlteracao` datetime DEFAULT NULL,
  `dataRegisto` datetime DEFAULT NULL,
  `valorPropina` float DEFAULT NULL,
  `totalPagamento` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`codAluno`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`aluno`
--

/*!40000 ALTER TABLE `aluno` DISABLE KEYS */;
INSERT INTO `aluno` (`codAluno`,`nome`,`endereco`,`telefone`,`telefoneAlternativo`,`dataNascimento`,`sexo`,`aluno_activo`,`dataAlteracao`,`dataRegisto`,`valorPropina`,`totalPagamento`) VALUES 
 (1,'Vilma Suzana','Camama','92323232323111','92323232321111','0000-00-00 00:00:00','Feminino',1,'2021-05-15 00:00:00','2021-05-15 00:00:00',200,'6'),
 (3,'Leu','Malanje','9999595959590','9895959595950','0000-00-00 00:00:00','Masculino',0,NULL,NULL,350,'1'),
 (4,'Alexandra Matias','Zango 3','9999999999999','9999999999999','0000-00-00 00:00:00','Masculino',0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `aluno` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`aluno_turma`
--

DROP TABLE IF EXISTS `aluno_turma`;
CREATE TABLE `aluno_turma` (
  `codTurma` int(11) DEFAULT NULL,
  `codAluno` int(11) DEFAULT NULL,
  KEY `codTurma` (`codTurma`),
  KEY `codAluno` (`codAluno`),
  CONSTRAINT `aluno_turma_ibfk_1` FOREIGN KEY (`codTurma`) REFERENCES `turma` (`codTurma`),
  CONSTRAINT `aluno_turma_ibfk_2` FOREIGN KEY (`codAluno`) REFERENCES `aluno` (`codAluno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`aluno_turma`
--

/*!40000 ALTER TABLE `aluno_turma` DISABLE KEYS */;
INSERT INTO `aluno_turma` (`codTurma`,`codAluno`) VALUES 
 (9,1),
 (10,3),
 (10,1),
 (9,3),
 (10,4);
/*!40000 ALTER TABLE `aluno_turma` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`curso`
--

DROP TABLE IF EXISTS `curso`;
CREATE TABLE `curso` (
  `codCurso` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `dataRegisto` datetime DEFAULT NULL,
  `dataAlteracao` datetime DEFAULT NULL,
  `curso_activo` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`codCurso`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`curso`
--

/*!40000 ALTER TABLE `curso` DISABLE KEYS */;
INSERT INTO `curso` (`codCurso`,`nome`,`dataRegisto`,`dataAlteracao`,`curso_activo`) VALUES 
 (2,'Semba','2020-05-17 00:00:00','2020-05-17 00:00:00','0'),
 (4,'Kizomba',NULL,NULL,'0'),
 (5,'Popping',NULL,NULL,'1'),
 (6,'Valsa',NULL,NULL,'0');
/*!40000 ALTER TABLE `curso` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`especialidade`
--

DROP TABLE IF EXISTS `especialidade`;
CREATE TABLE `especialidade` (
  `codEspecialidade` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `especialidade_activo` int(10) unsigned DEFAULT NULL,
  `dataAlteracao` datetime DEFAULT NULL,
  `dataRegisto` datetime DEFAULT NULL,
  PRIMARY KEY (`codEspecialidade`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`especialidade`
--

/*!40000 ALTER TABLE `especialidade` DISABLE KEYS */;
INSERT INTO `especialidade` (`codEspecialidade`,`nome`,`especialidade_activo`,`dataAlteracao`,`dataRegisto`) VALUES 
 (1,'Samba',0,'2020-05-05 00:00:00','2020-05-05 00:00:00'),
 (3,'Hip Hop',1,NULL,NULL);
/*!40000 ALTER TABLE `especialidade` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `escola_bd`.`groups`
--

/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` (`id`,`name`,`description`) VALUES 
 (1,'admin','Administrador'),
 (2,'usuario','Usuarios');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `escola_bd`.`login_attempts`
--

/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`mensalidade`
--

DROP TABLE IF EXISTS `mensalidade`;
CREATE TABLE `mensalidade` (
  `codMensalidade` int(11) NOT NULL AUTO_INCREMENT,
  `codAluno` int(11) DEFAULT NULL,
  `estado` varchar(10) DEFAULT NULL,
  `dataPagamento` datetime DEFAULT NULL,
  `valorPropina` float DEFAULT NULL,
  `mes` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`codMensalidade`),
  KEY `codAluno` (`codAluno`),
  CONSTRAINT `mensalidade_ibfk_1` FOREIGN KEY (`codAluno`) REFERENCES `aluno` (`codAluno`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`mensalidade`
--

/*!40000 ALTER TABLE `mensalidade` DISABLE KEYS */;
INSERT INTO `mensalidade` (`codMensalidade`,`codAluno`,`estado`,`dataPagamento`,`valorPropina`,`mes`) VALUES 
 (5,3,'PAGO',NULL,200,'Janeiro'),
 (8,1,'PAGO',NULL,2000,'Janeiro'),
 (9,1,'PAGO',NULL,200,'Maio'),
 (10,1,'PAGO',NULL,200,'Junho');
/*!40000 ALTER TABLE `mensalidade` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`mes`
--

DROP TABLE IF EXISTS `mes`;
CREATE TABLE `mes` (
  `codMes` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`codMes`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`mes`
--

/*!40000 ALTER TABLE `mes` DISABLE KEYS */;
INSERT INTO `mes` (`codMes`,`nome`) VALUES 
 (1,'Janeiro'),
 (2,'Fevereiro'),
 (3,'Março'),
 (4,'Abril'),
 (5,'Maio'),
 (6,'Junho'),
 (7,'Julho'),
 (8,'Agosto'),
 (9,'Setembro'),
 (10,'Outubro'),
 (11,'Novembro'),
 (12,'Dezembro');
/*!40000 ALTER TABLE `mes` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`professor`
--

DROP TABLE IF EXISTS `professor`;
CREATE TABLE `professor` (
  `codProfessor` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `sexo` varchar(10) DEFAULT NULL,
  `dataNascimento` datetime DEFAULT NULL,
  `endereco` varchar(10) DEFAULT NULL,
  `telefone` varchar(45) DEFAULT NULL,
  `professor_activo` int(10) unsigned DEFAULT NULL,
  `dataAlteracao` datetime DEFAULT NULL,
  `dataRegisto` datetime DEFAULT NULL,
  PRIMARY KEY (`codProfessor`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`professor`
--

/*!40000 ALTER TABLE `professor` DISABLE KEYS */;
INSERT INTO `professor` (`codProfessor`,`nome`,`sexo`,`dataNascimento`,`endereco`,`telefone`,`professor_activo`,`dataAlteracao`,`dataRegisto`) VALUES 
 (2,'Benson Sebastiao Capanga Antonio','Masculino','2015-04-15 00:00:00','Calemba 2','888888888888',0,NULL,NULL),
 (3,'Benicio Alexandre Capanga Antonio','Masculino','0000-00-00 00:00:00','Camama','92324526256234',1,NULL,NULL),
 (4,'',NULL,'0000-00-00 00:00:00',NULL,NULL,2,NULL,NULL),
 (5,'Alexandra Matias','Feminino','0000-00-00 00:00:00','Zango 2','9999999999999',1,NULL,NULL);
/*!40000 ALTER TABLE `professor` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`professor_especialidade`
--

DROP TABLE IF EXISTS `professor_especialidade`;
CREATE TABLE `professor_especialidade` (
  `codEspecialidade` int(11) DEFAULT NULL,
  `codProfessor` int(11) DEFAULT NULL,
  KEY `codEspecialidade` (`codEspecialidade`),
  KEY `codProfessor` (`codProfessor`),
  CONSTRAINT `professor_especialidade_ibfk_1` FOREIGN KEY (`codEspecialidade`) REFERENCES `especialidade` (`codEspecialidade`),
  CONSTRAINT `professor_especialidade_ibfk_2` FOREIGN KEY (`codProfessor`) REFERENCES `professor` (`codProfessor`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`professor_especialidade`
--

/*!40000 ALTER TABLE `professor_especialidade` DISABLE KEYS */;
/*!40000 ALTER TABLE `professor_especialidade` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`sistema`
--

DROP TABLE IF EXISTS `sistema`;
CREATE TABLE `sistema` (
  `sistema_id` int(11) NOT NULL AUTO_INCREMENT,
  `sistema_razao_social` varchar(145) DEFAULT NULL,
  `sistema_nome_fantasia` varchar(145) DEFAULT NULL,
  `sistema_cnpj` varchar(25) DEFAULT NULL,
  `sistema_ie` varchar(25) DEFAULT NULL,
  `sistema_telefone_fixo` varchar(25) DEFAULT NULL,
  `sistema_telefone_movel` varchar(25) NOT NULL,
  `sistema_email` varchar(100) DEFAULT NULL,
  `sistema_site_url` varchar(100) DEFAULT NULL,
  `sistema_cep` varchar(25) DEFAULT NULL,
  `sistema_endereco` varchar(145) DEFAULT NULL,
  `sistema_numero` varchar(25) DEFAULT NULL,
  `sistema_cidade` varchar(45) DEFAULT NULL,
  `sistema_estado` varchar(2) DEFAULT NULL,
  `sistema_txt_ordem_servico` tinytext,
  `sistema_data_alteracao` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`sistema_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`sistema`
--

/*!40000 ALTER TABLE `sistema` DISABLE KEYS */;
/*!40000 ALTER TABLE `sistema` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`turma`
--

DROP TABLE IF EXISTS `turma`;
CREATE TABLE `turma` (
  `codTurma` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `horario` varchar(12) DEFAULT NULL,
  `diaSemana` varchar(10) DEFAULT NULL,
  `dataAlteracao` datetime DEFAULT NULL,
  `dataRegisto` datetime DEFAULT NULL,
  `turma_activo` int(11) DEFAULT NULL,
  `codProfessor` int(11) NOT NULL DEFAULT '0',
  `professorAuxiliar` int(11) DEFAULT NULL,
  `valorPropina` float DEFAULT NULL,
  `codCurso` int(11) DEFAULT NULL,
  PRIMARY KEY (`codTurma`),
  KEY `codProfessor_idx` (`codProfessor`),
  KEY `professorAuxiliar_idx` (`professorAuxiliar`),
  KEY `codCurso_idx` (`codCurso`),
  CONSTRAINT `codCurso` FOREIGN KEY (`codCurso`) REFERENCES `curso` (`codCurso`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `codProfessor` FOREIGN KEY (`codProfessor`) REFERENCES `professor` (`codProfessor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `professorAuxiliar` FOREIGN KEY (`professorAuxiliar`) REFERENCES `professor` (`codProfessor`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`turma`
--

/*!40000 ALTER TABLE `turma` DISABLE KEYS */;
INSERT INTO `turma` (`codTurma`,`nome`,`horario`,`diaSemana`,`dataAlteracao`,`dataRegisto`,`turma_activo`,`codProfessor`,`professorAuxiliar`,`valorPropina`,`codCurso`) VALUES 
 (9,'Semba','10:00','Segunda',NULL,NULL,1,2,2,200,2),
 (10,'Popping','14:00','Quarta',NULL,NULL,1,3,4,300,5),
 (11,'Popping','15:00','Quinta',NULL,NULL,1,2,4,300,5);
/*!40000 ALTER TABLE `turma` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`turma_curso`
--

DROP TABLE IF EXISTS `turma_curso`;
CREATE TABLE `turma_curso` (
  `codTurma` int(11) DEFAULT NULL,
  `codCurso` int(11) DEFAULT NULL,
  KEY `codTurma` (`codTurma`),
  KEY `codCurso` (`codCurso`),
  CONSTRAINT `turma_curso_ibfk_1` FOREIGN KEY (`codTurma`) REFERENCES `turma` (`codTurma`),
  CONSTRAINT `turma_curso_ibfk_2` FOREIGN KEY (`codCurso`) REFERENCES `curso` (`codCurso`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`turma_curso`
--

/*!40000 ALTER TABLE `turma_curso` DISABLE KEYS */;
/*!40000 ALTER TABLE `turma_curso` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`turma_professor`
--

DROP TABLE IF EXISTS `turma_professor`;
CREATE TABLE `turma_professor` (
  `codProfessor` int(11) DEFAULT NULL,
  `codTurma` int(11) DEFAULT NULL,
  KEY `codProfessor` (`codProfessor`),
  KEY `codTurma` (`codTurma`),
  CONSTRAINT `turma_professor_ibfk_1` FOREIGN KEY (`codProfessor`) REFERENCES `professor` (`codProfessor`),
  CONSTRAINT `turma_professor_ibfk_2` FOREIGN KEY (`codTurma`) REFERENCES `turma` (`codTurma`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `escola_bd`.`turma_professor`
--

/*!40000 ALTER TABLE `turma_professor` DISABLE KEYS */;
/*!40000 ALTER TABLE `turma_professor` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `activation_selector` varchar(255) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `forgotten_password_selector` varchar(255) DEFAULT NULL,
  `forgotten_password_code` varchar(255) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_selector` varchar(255) DEFAULT NULL,
  `remember_code` varchar(255) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_email` (`email`),
  UNIQUE KEY `uc_activation_selector` (`activation_selector`),
  UNIQUE KEY `uc_forgotten_password_selector` (`forgotten_password_selector`),
  UNIQUE KEY `uc_remember_selector` (`remember_selector`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `escola_bd`.`users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`,`ip_address`,`username`,`password`,`email`,`activation_selector`,`activation_code`,`forgotten_password_selector`,`forgotten_password_code`,`forgotten_password_time`,`remember_selector`,`remember_code`,`created_on`,`last_login`,`active`,`first_name`,`last_name`,`company`,`phone`) VALUES 
 (1,'127.0.0.1','administrator','$2y$12$Ct7o4L/wgWllUR52KClAQuXcc5qgJurvRjR9jaIwg4bbv3Zat5WFa','admin@admin.com',NULL,'',NULL,NULL,NULL,NULL,NULL,1268889823,1591135474,1,'Admin','istrator','ADMIN','0'),
 (7,'::1','vilma','$2y$12$N42oQHfdNgGZd46ywprwYuUnq4Q2WCZpChv/QAVbYdiG.T5Z/sm1i','vilma@cajama.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1589230171,1589236361,0,'vilma',NULL,NULL,NULL),
 (8,'::1','cajama','$2y$10$Q2/5hTG4zV8ngZDa4VGWtOjCVHqzE7EUU2QsM7zX.IJDZJdDmopFK','cajama@cajama.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1590176733,1591045672,1,'Vilma',NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;


--
-- Table structure for table `escola_bd`.`users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `escola_bd`.`users_groups`
--

/*!40000 ALTER TABLE `users_groups` DISABLE KEYS */;
INSERT INTO `users_groups` (`id`,`user_id`,`group_id`) VALUES 
 (1,1,1),
 (2,1,2),
 (14,7,2),
 (17,8,2);
/*!40000 ALTER TABLE `users_groups` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
